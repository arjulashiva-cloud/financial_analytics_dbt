{{
    config(
        materialized = 'view',
        description  = 'Cleaned and typed customer records from RAW_CUSTOMERS. One row per customer.'
    )
}}

with source as (

    select * from {{ source('raw', 'RAW_CUSTOMERS') }}

),

renamed as (

    select
        -- Keys
        customer_id,

        -- Demographics
        first_name,
        last_name,
        first_name || ' ' || last_name                          as full_name,
        email,
        phone,
        try_to_date(date_of_birth)                              as date_of_birth,
        age,
        gender,

        -- Geography
        city,
        state,
        zip_code,

        -- Financial profile
        income_band,
        credit_score,

        -- Relationship
        try_to_date(customer_since_date)                        as customer_since_date,
        tenure_months,
        acquisition_channel,

        -- Risk & segmentation
        churn_risk_score,
        lifecycle_stage,
        relationship_value_tier,
        is_active,

        -- Derived convenience flags
        case
            when credit_score >= 800 then 'exceptional'
            when credit_score >= 740 then 'very_good'
            when credit_score >= 670 then 'good'
            when credit_score >= 580 then 'fair'
            else 'poor'
        end                                                     as credit_tier,

        case
            when tenure_months >= 120 then '10y+'
            when tenure_months >= 60  then '5-10y'
            when tenure_months >= 24  then '2-5y'
            when tenure_months >= 12  then '1-2y'
            else '<1y'
        end                                                     as tenure_bucket,

        -- Audit
        created_at

    from source

)

select * from renamed
