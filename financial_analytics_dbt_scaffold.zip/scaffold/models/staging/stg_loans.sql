{{
    config(
        materialized = 'view',
        description  = 'Cleaned loan records — auto, mortgage, personal, HELOC.'
    )
}}

with source as (

    select * from {{ source('raw', 'RAW_LOANS') }}

),

renamed as (

    select
        -- Keys
        loan_id,
        customer_id,

        -- Loan attributes
        loan_type,              -- AUTO | MORTGAGE | PERSONAL | HELOC
        loan_status,            -- CURRENT | 30DPD | 60DPD | 90DPD | DEFAULT | PAID_OFF | CHARGED_OFF
        origination_date,
        maturity_date,
        term_months,

        -- Financials
        original_principal,
        current_balance,
        monthly_payment,
        interest_rate,
        annual_percentage_rate,

        -- Credit risk inputs (CECL)
        days_past_due,
        times_30dpd_last_12m,
        times_60dpd_last_12m,
        loan_to_value_ratio,    -- for secured loans
        debt_to_income_ratio,

        -- Derived
        original_principal - current_balance                        as principal_paid,

        case
            when loan_status = 'CURRENT'      then 1
            when loan_status = '30DPD'        then 2
            when loan_status = '60DPD'        then 3
            when loan_status = '90DPD'        then 4
            when loan_status in ('DEFAULT','CHARGED_OFF') then 5
            else 0
        end                                                         as delinquency_severity,

        -- EAD = exposure at default (current balance for simple approach)
        current_balance                                             as exposure_at_default,

        -- Is this loan still open?
        loan_status not in ('PAID_OFF', 'CHARGED_OFF')             as is_active,

        -- Audit
        created_at

    from source

)

select * from renamed
