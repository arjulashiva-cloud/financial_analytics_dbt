{{
    config(
        materialized = 'view',
        description  = 'Cleaned transaction records. One row per transaction.'
    )
}}

with source as (

    select * from {{ source('raw', 'RAW_TRANSACTIONS') }}

),

renamed as (

    select
        -- Keys
        transaction_id,
        account_id,
        customer_id,

        -- Transaction details
        transaction_date,
        transaction_type,        -- DEBIT | CREDIT
        transaction_category,    -- e.g. purchase, payroll, transfer, fee, atm
        merchant_category_code,
        merchant_name,
        channel,                 -- online | mobile | branch | atm | pos

        -- Amount — always positive; direction captured in transaction_type
        abs(amount)              as amount,
        transaction_type = 'DEBIT' as is_debit,
        transaction_type = 'CREDIT' as is_credit,

        -- Running balance snapshot
        balance_after,

        -- Overdraft flag
        balance_after < 0        as is_overdraft,

        -- Time dimensions (pre-computed for downstream marts)
        date_trunc('month', transaction_date)   as transaction_month,
        date_trunc('week',  transaction_date)   as transaction_week,
        dayofweek(transaction_date)             as day_of_week,    -- 0=Sun
        hour(transaction_date)                  as hour_of_day,

        -- Audit
        created_at

    from source

)

select * from renamed
