{{
    config(
        materialized = 'view',
        description  = 'Cleaned account records from RAW_ACCOUNTS. One row per account.'
    )
}}

with source as (

    select * from {{ source('raw', 'RAW_ACCOUNTS') }}

),

renamed as (

    select
        -- Keys
        account_id,
        customer_id,

        -- Product
        account_type,
        account_status,

        -- Dates
        try_to_date(open_date)          as open_date,
        try_to_date(close_date)         as close_date,
        try_to_date(cd_maturity_date)   as cd_maturity_date,
        cd_term_months,

        -- Financials
        current_balance,
        interest_rate,
        overdraft_limit,
        monthly_fee,
        fee_waiver_reason,

        -- Behavioral flags
        has_direct_deposit,
        has_autopay,

        -- Derived
        datediff('day', try_to_date(open_date), current_date())  as account_age_days,

        case
            when account_status = 'CLOSED'  then false
            when current_balance = 0        then false
            else true
        end                                                       as has_positive_balance,

        case account_type
            when 'CHECKING'       then 'DEPOSIT'
            when 'SAVINGS'        then 'DEPOSIT'
            when 'MONEY_MARKET'   then 'DEPOSIT'
            when 'CD'             then 'DEPOSIT'
            when 'IRA_TRADITIONAL'then 'RETIREMENT'
            when 'IRA_ROTH'       then 'RETIREMENT'
            else 'OTHER'
        end                                                       as product_category,

        -- CD maturity flag (within 90 days)
        case
            when account_type = 'CD'
             and try_to_date(cd_maturity_date) between current_date()
                                                    and dateadd('day', 90, current_date())
            then true
            else false
        end                                                       as cd_maturing_soon,

        -- Audit
        created_at

    from source

)

select * from renamed
