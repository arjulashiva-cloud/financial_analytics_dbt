{{
    config(
        materialized = 'view',
        description  = 'FRED API macro-economic indicators. Pivoted to one row per observation date.'
    )
}}

with source as (

    select * from {{ source('raw', 'RAW_FRED_MACRO') }}

),

pivoted as (

    select
        observation_date,

        max(case when series_id = 'FEDFUNDS'  then value end)   as fed_funds_rate,
        max(case when series_id = 'CPIAUCSL'  then value end)   as cpi_index,
        max(case when series_id = 'UNRATE'    then value end)   as unemployment_rate,
        max(case when series_id = 'GDPC1'     then value end)   as real_gdp_index,
        max(case when series_id = 'MORTGAGE30US' then value end) as avg_30yr_mortgage_rate,
        max(case when series_id = 'DRCCLACBS' then value end)   as credit_card_delinquency_rate

    from source
    group by observation_date

),

enriched as (

    select
        observation_date,
        fed_funds_rate,
        cpi_index,
        unemployment_rate,
        real_gdp_index,
        avg_30yr_mortgage_rate,
        credit_card_delinquency_rate,

        -- YoY CPI change (inflation proxy)
        cpi_index / nullif(
            lag(cpi_index, 12) over (order by observation_date), 0
        ) - 1                                                       as cpi_yoy_pct,

        -- Macro stress tier for CECL scenario selection
        case
            when unemployment_rate >= 8.0 then 'severely_adverse'
            when unemployment_rate >= 5.5 then 'adverse'
            else 'base'
        end                                                         as macro_scenario,

        date_trunc('month', observation_date)                       as observation_month

    from pivoted

)

select * from enriched
