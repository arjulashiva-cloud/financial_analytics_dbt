{{
    config(
        materialized = 'view',
        description  = 'Cleaned credit card accounts with utilization and payment behavior.'
    )
}}

with source as (

    select * from {{ source('raw', 'RAW_CREDIT_CARDS') }}

),

renamed as (

    select
        -- Keys
        card_id,
        customer_id,

        -- Card attributes
        card_type,          -- VISA | MASTERCARD | AMEX
        card_tier,          -- standard | gold | platinum | signature
        card_status,        -- ACTIVE | FROZEN | CLOSED | DELINQUENT

        -- Dates
        open_date,
        close_date,
        last_payment_date,

        -- Financials
        credit_limit,
        current_balance,
        minimum_payment,
        last_payment_amount,
        annual_fee,
        apr,

        -- Utilization (key churn + risk signal)
        current_balance / nullif(credit_limit, 0)               as utilization_rate,

        case
            when current_balance / nullif(credit_limit, 0) <= 0.10 then 'low'
            when current_balance / nullif(credit_limit, 0) <= 0.30 then 'moderate'
            when current_balance / nullif(credit_limit, 0) <= 0.70 then 'high'
            else 'maxed'
        end                                                     as utilization_bucket,

        -- Payment behavior
        times_30dpd_last_12m,
        times_60dpd_last_12m,
        consecutive_on_time_payments,

        -- Reward points
        rewards_points_balance,
        rewards_points_earned_ytd,

        -- Derived
        credit_limit - current_balance                          as available_credit,
        card_status = 'ACTIVE'                                  as is_active,

        -- Audit
        created_at

    from source

)

select * from renamed
